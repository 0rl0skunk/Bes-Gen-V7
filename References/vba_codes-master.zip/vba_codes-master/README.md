# VBA CODE

## INTRODUCTION
VBA code is a project that regroups VBA codes for Access and Excel.

The files are in .vb extension you might need to copy paste the cod in order for it work.

# Support / Development

If you are interested in me participating in some other projects for you relate to the current work that I have done I am currently available for remote and on-site consulting for small, large and enterprise teams. Please contact me at pendenquejohn@gmail.com with your needs and let's work together!
