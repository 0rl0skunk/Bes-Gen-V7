# VBA class, module, and form project codes

Excel, 
Outlook, 
Access, 
Powerpoint

## Large repository of folders containing .xlsm workbooks and code modules that the workbook contains
These VBA code examples come from a personal collection that I reference frequently.

### Extensive and in depth VBA code blocks for filesystems and other applications
Use the folders as a guide and modify the code to suit your needs. 
